namespace esercizio1
{
    public partial class Form1 : Form
    {
        Thread t1, t2;
        List<string> citta = new List<string>
        {
            "Roma",
            "Milano",
            "Napoli",
            "Torino",
            "Firenze"
        };

        //lista parallela
        List<int> abitanti = new List<int>
        {
            12,
            13,
            14,
            15,
            16
        };

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void modificaCitta()
        {
            foreach (string a in citta) 
            {

                Citta.Text = a.ToString();
                Thread.Sleep(1000);
            }
                Citta.Text = "";

            
        }

        public void visualizza()
        {
            foreach (int a in abitanti)
            {
                Abitanti.Text = a.ToString();
                Thread.Sleep(1000);
            }
                Abitanti.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            t1 = new Thread(modificaCitta);
            t2 = new Thread(visualizza);
            t1.Start();
            t2.Start();
        }
    }
}