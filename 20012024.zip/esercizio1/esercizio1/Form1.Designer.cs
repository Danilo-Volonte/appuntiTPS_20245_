﻿namespace esercizio1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Citta = new System.Windows.Forms.Label();
            this.Abitanti = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Citta
            // 
            this.Citta.AutoSize = true;
            this.Citta.Location = new System.Drawing.Point(63, 43);
            this.Citta.Name = "Citta";
            this.Citta.Size = new System.Drawing.Size(33, 15);
            this.Citta.TabIndex = 0;
            this.Citta.Text = "città:";
            // 
            // Abitanti
            // 
            this.Abitanti.AutoSize = true;
            this.Abitanti.Location = new System.Drawing.Point(356, 43);
            this.Abitanti.Name = "Abitanti";
            this.Abitanti.Size = new System.Drawing.Size(50, 15);
            this.Abitanti.TabIndex = 1;
            this.Abitanti.Text = "abitanti:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(252, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "avvia";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Abitanti);
            this.Controls.Add(this.Citta);
            this.Name = "Form1";
            this.Text = "esercizio1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Citta;
        private Label Abitanti;
        private Button button1;
    }
}