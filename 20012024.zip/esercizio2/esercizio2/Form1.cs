namespace esercizio2
{
    public partial class Form1 : Form
    {
        Thread t1;
        Random rnd= new Random();
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false; //per non fareri sultare errore con i vari Thraed 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void numeriCasuali()
        {
            MessageBox.Show("inzio");
            for (int i = 0; i >= 50; i--)
            {
                label1.Text = rnd.Next(1, 10).ToString();
                Thread.Sleep(1000);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            t1 = new Thread(numeriCasuali);
            t1.Start();
        }
    }
}