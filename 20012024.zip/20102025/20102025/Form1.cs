namespace _20102025
{
    public partial class Form1 : Form
    {
        Thread t1;
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void conta()
        {
            for(int i = 10; i >= 0; i--)
            {
                Thread.Sleep(500);
                label1.Text = i.ToString();
                Thread.Sleep(500);
            }
            button1.Enabled = true; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            t1 = new Thread(conta);
            t1.Start();
            label2.Text = "ID Thread: " + Thread.CurrentThread.ManagedThreadId.ToString();
            label2.Text = "ID t1: " + t1.ManagedThreadId.ToString();
        }
    }
}