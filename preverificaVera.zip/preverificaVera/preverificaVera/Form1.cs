using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
namespace preverificaVera
{
    
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        List<Biglietto> coda = new List<Biglietto>();
        List<Biglietto> zoo = new List<Biglietto>();
        Thread t1, t2, t3;
        
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void Casse_Click(object sender, EventArgs e)
        {
            t2 = new Thread(cassa);
            t3 = new Thread(cassa);
            t2.Start();
            t3.Start();
        }


        public void aggiorna()
        {
            PersonaZoo.Text = zoo.Count().ToString();
            PersoneCoda.Text = coda.Count().ToString();
            /*foreach(Biglietto p in zoo ) 
            {
                Biglietto a = (Biglietto)p;
                ProfittoTutto.Text = (p.costo).ToString();
            }*/
        }
        public void produttore()
        {
            for(int i = 0; i < 200; i++)
            {
                int anni = rnd.Next(1,110);
                Biglietto a = new Biglietto(anni);
                coda.Add(a);
                Thread.Sleep(25);
                aggiorna();
            }
        }

        public void cassa()
        {
            int x = 0;
            while ((coda.Count()) > 0)
            {
                if(x == 100) 
                {
                    Thread.Sleep(100);
                }
                zoo.Add(coda[coda.Count-1]);
                coda.RemoveAt(coda.Count-1);
                int intervallo = rnd.Next(20, 30);
                Thread.Sleep(intervallo);
                x++;
                aggiorna();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Coda_Click(object sender, EventArgs e)
        {
            t1 = new Thread(produttore);
            t1.Start();
        }
    }
}