﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace preverificaVera
{
    public class Biglietto
    {
        public int anni;
        public int Anni
        {
            get { return anni; }
            set
            {
                if(value >= 0 && value < 110)
                {
                    anni = value;
                }
                else
                {
                    MessageBox.Show("glia anni inseri non vanno bene");
                }
            }
        }


        public string tipo;
        public string Tipo
        {
            get { return tipo; }
            set
            {
                if (anni < 18)
                {
                    tipo = "ridotto";
                }
                else if (anni > 65)
                {
                    tipo = "anziani";
                }
                else
                {
                    tipo = "intero";
                }
            }
        }

        public int costo;
        public int Costo
        {
            get { return costo; }
            set
            {
                if (tipo == "intero")
                {
                    costo = 15;
                }
                else
                {
                    costo = 7;
                }
            }
        }

        public Biglietto(int anni)
        {
            this.anni = anni;
        }
    }
}
