﻿namespace preverificaVera
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Coda = new System.Windows.Forms.Button();
            this.Casse = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PersoneCoda = new System.Windows.Forms.TextBox();
            this.PersonaZoo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ProfittoCassa1 = new System.Windows.Forms.TextBox();
            this.ProfittoCassa2 = new System.Windows.Forms.TextBox();
            this.ProfittoTutto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Coda
            // 
            this.Coda.Location = new System.Drawing.Point(74, 323);
            this.Coda.Name = "Coda";
            this.Coda.Size = new System.Drawing.Size(75, 23);
            this.Coda.TabIndex = 0;
            this.Coda.Text = "avvia coda ";
            this.Coda.UseVisualStyleBackColor = true;
            this.Coda.Click += new System.EventHandler(this.Coda_Click);
            // 
            // Casse
            // 
            this.Casse.Location = new System.Drawing.Point(269, 324);
            this.Casse.Name = "Casse";
            this.Casse.Size = new System.Drawing.Size(75, 23);
            this.Casse.TabIndex = 1;
            this.Casse.Text = "avvia casse ";
            this.Casse.UseVisualStyleBackColor = true;
            this.Casse.Click += new System.EventHandler(this.Casse_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "persone in coda:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(303, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "persona nello zoo:";
            // 
            // PersoneCoda
            // 
            this.PersoneCoda.Location = new System.Drawing.Point(78, 123);
            this.PersoneCoda.Name = "PersoneCoda";
            this.PersoneCoda.Size = new System.Drawing.Size(100, 23);
            this.PersoneCoda.TabIndex = 4;
            // 
            // PersonaZoo
            // 
            this.PersonaZoo.Location = new System.Drawing.Point(302, 125);
            this.PersonaZoo.Name = "PersonaZoo";
            this.PersonaZoo.Size = new System.Drawing.Size(100, 23);
            this.PersonaZoo.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "profitto cassa 1:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(302, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "profitto cassa 2:";
            // 
            // ProfittoCassa1
            // 
            this.ProfittoCassa1.Location = new System.Drawing.Point(74, 219);
            this.ProfittoCassa1.Name = "ProfittoCassa1";
            this.ProfittoCassa1.Size = new System.Drawing.Size(100, 23);
            this.ProfittoCassa1.TabIndex = 8;
            // 
            // ProfittoCassa2
            // 
            this.ProfittoCassa2.Location = new System.Drawing.Point(302, 219);
            this.ProfittoCassa2.Name = "ProfittoCassa2";
            this.ProfittoCassa2.Size = new System.Drawing.Size(100, 23);
            this.ProfittoCassa2.TabIndex = 9;
            // 
            // ProfittoTutto
            // 
            this.ProfittoTutto.Location = new System.Drawing.Point(542, 161);
            this.ProfittoTutto.Name = "ProfittoTutto";
            this.ProfittoTutto.Size = new System.Drawing.Size(100, 23);
            this.ProfittoTutto.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(542, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "profitto totale:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ProfittoTutto);
            this.Controls.Add(this.ProfittoCassa2);
            this.Controls.Add(this.ProfittoCassa1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PersonaZoo);
            this.Controls.Add(this.PersoneCoda);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Casse);
            this.Controls.Add(this.Coda);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button Coda;
        private Button Casse;
        private Label label1;
        private Label label2;
        private TextBox PersoneCoda;
        private TextBox PersonaZoo;
        private Label label3;
        private Label label4;
        private TextBox ProfittoCassa1;
        private TextBox ProfittoCassa2;
        private TextBox ProfittoTutto;
        private Label label5;
    }
}